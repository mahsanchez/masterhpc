/* Obtain the PI value using the numerical integration of 4/(1+x*x) between 0 and 1.
The numerical integration is calculated with n rectangular intervals (area=(1/n)*4/(1+x*x))) 
and adding the area of all these rectangle intervals  */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>


int main(argc,argv)
int argc;
char *argv[];
{
    int n, i;
    int provided;
    double PI25DT = 3.141592653589793238462643;
    double pi, h, h1, sum, x, result;

    int rank;
    int size;

	MPI_Init(&argc, &argv); 
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0) {
       n=atoi(argv[1]); 
    }
       
	double t=-MPI_Wtime();
	
	MPI_Request request = MPI_REQUEST_NULL;
    MPI_Ibcast(&n, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD, &request);
	MPI_Wait(&request, MPI_STATUS_IGNORE); 

    h = 1.0 / (double) n;  //wide of the rectangle

    int block_size = n/size;
    int initial = rank * block_size;
    int end = rank*block_size + block_size;

    sum = 0.0;
    for (i = initial; i < end; i++) {
	    x = h * ((double)i + 0.5);   //height of the rectangle
        sum += 4.0 / (1.0 + x*x);
    }

    MPI_Ireduce(&sum, &result, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD, &request);
    MPI_Wait(&request, MPI_STATUS_IGNORE);	
	
	t+=MPI_Wtime();

    if (rank == 0) {
       pi = h * result;
       printf("The obtained Pi value is: %.16f, the error is: %.16f time %f\n", pi, fabs(pi - PI25DT), t);
    }

    MPI_Finalize();
}
