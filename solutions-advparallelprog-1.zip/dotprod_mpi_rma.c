/* Dot product of two vectors */

#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

int main(argc,argv)
int argc;
char *argv[];
{
    int N=100000000, i, chunk_size; 
	int rank, provided, numprocs;
    float *x, *y, *local_x, *local_y;
    float dot, local_dot;
    
    if (argc < 2) {
     	fprintf(stderr,"Use: %s num_elem_vector\n", argv[0]);
     	exit(EXIT_FAILURE);
    }

    N = atoi(argv[1]);
	
	MPI_Init(&argc, &argv);
	
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	
	if (N % numprocs !=0) {
       if (rank==0) printf("Vector size not divisible by number of processors\n");
       MPI_Finalize();
       exit(-1);
    }
    
	chunk_size = N/numprocs;
	
	double t=-MPI_Wtime();
	
	float *local_xy = (float *) malloc(2 * N * sizeof(float));
	MPI_Win win;
	MPI_Win_create(local_xy, 2 * N * sizeof(float), 1, MPI_INFO_NULL, MPI_COMM_WORLD, &win);
	
    /* Inicialization of x and y vectors*/
	MPI_Win_fence(0, win); 
	if (rank == 0) {
		for (i=0; i<N; i++) {
			local_xy[i] = (N/2.0 - i);
			local_xy[N + i] = 0.0001*i;
        }
	}
	MPI_Win_fence(0, win); 
	
	MPI_Win_fence(0, win); 
	if (rank > 0) {
	    MPI_Get(local_xy, chunk_size, MPI_FLOAT, 0, rank * chunk_size* sizeof(float), chunk_size, MPI_FLOAT, win);
	}	
	MPI_Win_fence(0, win); 
	
	MPI_Win_fence(0, win); 
	if (rank > 0) {
	    MPI_Get(&local_xy[chunk_size], chunk_size, MPI_FLOAT, 0, N + (rank * chunk_size) * sizeof(float), chunk_size, MPI_FLOAT, win);
	}	
	MPI_Win_fence(0, win); 

    // Dot product operation 
    local_dot = 0.;
    for(i=0; i < chunk_size; i++)
	    local_dot += local_xy[i] * local_xy[chunk_size + i];
	
	printf("Dot rank %d product = %f\n", rank, local_dot);
		
	
	//MPI_Reduce(&local_dot, &dot, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
	
	MPI_Win_fence(0, win); 
	if (rank == 0) {
		local_xy[0] = local_dot;
	}
	MPI_Win_fence(0, win); 
	
	MPI_Win_fence(0, win); 
	if (rank > 0) {
		MPI_Accumulate(&local_dot, 1, MPI_FLOAT, 0, 0, 1, MPI_FLOAT, MPI_SUM, win);
	}
    MPI_Win_fence(0, win); 
	
	t+=MPI_Wtime();
    
    if (rank == 0) {
		printf("Dot product = %g  time %f\n", local_xy[0], t);
	} 
	
	MPI_Win_free(&win);;
	
	MPI_Finalize();

    return 0;
}



