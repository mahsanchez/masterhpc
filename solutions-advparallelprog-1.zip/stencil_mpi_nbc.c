// Compile with mpicc -o stencil stencil.c -lm
// Example for run: mpirun -np 1 ./stencil 200 1 500
// Output: heat.svg

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>

// row-major order
#define ind(i,j) (j)*(n+2)+i

void printarr(double *a, int n) {
  // does nothing right now, should record each "frame" as image
  FILE *fp = fopen("heat.svg", "w");
  const int size = 5;

  fprintf(fp, "<html>\n<body>\n<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">");

  fprintf(fp, "\n<rect x=\"0\" y=\"0\" width=\"%i\" height=\"%i\" style=\"stroke-width:1;fill:rgb(0,0,0);stroke:rgb(0,0,0)\"/>", size*n, size*n);
  for(int i=1; i<n+1; ++i)
    for(int j=1; j<n+1; ++j) {
      int rgb = (a[ind(i,j)] > 0) ? rgb = (int)round(255.0*a[ind(i,j)]) : 0.0;
      if(rgb>255) rgb=255;
      if(rgb) fprintf(fp, "\n<rect x=\"%i\" y=\"%i\" width=\"%i\" height=\"%i\" style=\"stroke-width:1;fill:rgb(%i,0,0);stroke:rgb(%i,0,0)\"/>", size*(i-1), size*(j-1), size, size, rgb, rgb);
    }
  fprintf(fp, "</svg>\n</body>\n</html>");


  fclose(fp);
}

int main(int argc, char **argv) {

  int n ; // nxn grid
  int energy; // energy to be injected per iteration
  int niters; // number of iterations
  int rank, procnum;
  int parameters[3];

  MPI_Init(&argc, &argv); 
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &procnum);
  
   if(argc < 4) {
	  if (rank == 0) printf("usage: stencil_mpi <n> <energy> <niters>\n");
	  MPI_Finalize();
	  exit(1);
  }
  
  if (rank == 0) {
      n = atoi(argv[1]);
      energy = atoi(argv[2]); 
      niters = atoi(argv[3]); 
  }	  
  
  // stencil parameters
  if (rank == 0) {
      int args[3] = {n, energy, niters};
      MPI_Bcast(args, 3, MPI_INT, 0, MPI_COMM_WORLD);
  }
  else {
      int args[3];
      MPI_Bcast(args, 3, MPI_INT, 0, MPI_COMM_WORLD);
      n=args[0]; energy=args[1]; niters=args[2];
  }
  
  //printf("parameters rank:%d grid_size:%d energy:%d number_iterations:%d \n", rank, n, energy, niters);
  
  // Cartesian Topology Creation
  int dimension[2] = {0,0};
  MPI_Dims_create(procnum, 2, dimension);
  
  int periods[2] = {0,0};
  MPI_Comm cartesian_topology;
  MPI_Cart_create(MPI_COMM_WORLD, 2, dimension, periods, 0, &cartesian_topology);

  // Get x,y coordinates per process
  int coordinates[2];
  MPI_Cart_coords(cartesian_topology, rank, 2, coordinates);

  // Find neighbors ranks
  int source, north, south, east, west;
  MPI_Cart_shift(cartesian_topology, 0, 1, &west, &east);
  MPI_Cart_shift(cartesian_topology, 1, 1, &north, &south);
  
  int px = dimension[0];
  int py = dimension[1];
  int rx = coordinates[0];
  int ry = coordinates[1];
  
  printf("parameters rank:%d dimension{%d, %d} coordinates{%d, %d} north:%d south:%d east:%d west:%d \n", rank, px, py, rx, ry, north, south, east, west);
  
  // Split the grid on equally small tiles sizes
  int tile_width = n/px; 
  int tile_height = n/py; 
  int offset_x = rx * tile_width; 
  int offset_y = ry * tile_height; 
  
  // reserve memory per process, add space for halo zones
  double *aold = (double*)calloc(1,(n+2)*(n+2)*sizeof(double)); 
  double *anew = (double*)calloc(1,(n+2)*(n+2)*sizeof(double)); 
  double *tmp;
  
  #define nsources 3
  int sources[nsources][2] = {{n/2,n/2}, {n/3,n/3}, {n*4/5,n*8/9}};
  
  // find out if there are energy source assigned to this process tile
  int tile[nsources][2]; 
  int lnsources = 0;
  
  for (int i=0; i < nsources; ++i) {
    int local_x = sources[i][0] - offset_x;
    int local_y = sources[i][1] - offset_y;
    if( (local_x >= 0 && local_x < tile_width) && (local_y >= 0 && local_y < tile_height)) {
      tile[lnsources][0] = local_x + 1; 
      tile[lnsources][1] = local_y + 1; 
      lnsources++;
    }
  }
  
  double heat=0.0; // total heat in system
  double t=-MPI_Wtime();
  
  MPI_Request request;
  MPI_Status status;
  
  for(int iter=0; iter<niters; ++iter) {
    heat = 0.0;
	
	// reserve memory 
    double *sbuf = (double*)calloc(1,2*tile_width*sizeof(double)+2*tile_height*sizeof(double)); 
    double *rbuf = (double*)calloc(1,2*tile_width*sizeof(double)+2*tile_height*sizeof(double)); 
	
    for(int i=0; i<tile_height; ++i) sbuf[i] = aold[ind(1,i+1)];   	                   // halo-east
    for(int i=0; i<tile_height; ++i) sbuf[tile_height+i] = aold[ind(tile_width,i+1)];  // halo-west
    for(int i=0; i<tile_width; ++i) sbuf[2*tile_height+i] = aold[ind(i+1,1)];          // halo-west
    for(int i=0; i<tile_width; ++i) sbuf[2*tile_height+tile_width+i] = aold[ind(i+1,tile_height)]; // halo-south
	
	int counts[4] = {tile_height, tile_height, tile_width, tile_width};
    int displs[4] = {0, tile_height, 2*tile_height, 2*tile_height+tile_width};
	
	// hallo exchange
    MPI_Ineighbor_alltoallv(sbuf, counts, displs, MPI_DOUBLE, rbuf, counts, displs, MPI_DOUBLE, cartesian_topology, &request);
    MPI_Wait(&request, &status);
	
    for(int i=0; i<tile_height; ++i) aold[ind(0,i+1)] = rbuf[i]; 
    for(int i=0; i<tile_height; ++i) aold[ind(tile_width+1,i+1)] = rbuf[tile_height+i]; 
    for(int i=0; i<tile_width; ++i) aold[ind(i+1,0)] = rbuf[2*tile_height+i]; 
    for(int i=0; i<tile_width; ++i) aold[ind(i+1,tile_height+1)] = rbuf[2*tile_height+tile_width+i]; 
	
    for(int j=1; j < tile_height + 1; ++j) {
      for(int i=1; i < tile_width + 1; ++i) {
        anew[ind(i,j)] = aold[ind(i,j)]/2.0 + (aold[ind(i-1,j)] + aold[ind(i+1,j)] + aold[ind(i,j-1)] + aold[ind(i,j+1)])/4.0/2.0;
        heat += anew[ind(i,j)];
      }
    }
	
	// update the heat
	for(int i=0; i < lnsources; ++i) {
      anew[ind(tile[i][0],tile[i][1])] += energy; // heat source
    }
	
    tmp=anew; anew=aold; aold=tmp; 
  }
  
  t+=MPI_Wtime();
  
  double total_heat;
  MPI_Ireduce(&heat, &total_heat, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD, &request);
  MPI_Wait(&request, &status);
  
  if (rank == 0) {
	  //printarr(anew, n); run a gather here to read all tiles
      printf("last heat: %f time: %f\n", total_heat, t); 
  }
  
  
  MPI_Finalize();
}