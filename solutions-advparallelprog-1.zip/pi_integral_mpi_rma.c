/* Obtain the PI value using the numerical integration of 4/(1+x*x) between 0 and 1.
The numerical integration is calculated with n rectangular intervals (area=(1/n)*4/(1+x*x))) 
and adding the area of all these rectangle intervals  */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>


int main(argc,argv)
int argc;
char *argv[];
{
    int i;
    double PI25DT = 3.141592653589793238462643;
    double pi, h, h1, sum, n, x;

    int rank;
    int size;

    MPI_Init(&argc, &argv);
	
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0) {
       n = (double) atoi(argv[1]);
    }
       
	double t=-MPI_Wtime();
	
	double *result;
    MPI_Win win;
    MPI_Win_allocate(2 * sizeof(double), sizeof(double), MPI_INFO_NULL, MPI_COMM_WORLD, &result, &win);
	
	if (rank == 0) {
	  *result = n;
	}
	
	MPI_Win_fence(0, win); 
	MPI_Get(&n, 1, MPI_DOUBLE, 0, 0, 1, MPI_DOUBLE, win);
	MPI_Win_fence(0, win); 
	
	// initialize value to zero in process with rank 0
	if (rank == 0) {
	  *result = 0;
	}

    h = 1.0 / (double) n;  //wide of the rectangle

    int block_size = n/size;
    int initial = rank * block_size;
    int end = rank*block_size + block_size;

    sum = 0.0;
    for (i = initial; i < end; i++) {
	    x = h * ((double)i + 0.5);   //height of the rectangle
        sum += 4.0 / (1.0 + x*x);
    }

    //MPI_Reduce(&sum, &result, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD); 
	MPI_Win_fence(0, win); 
    MPI_Accumulate(&sum, 1, MPI_DOUBLE, 0, 0, 1, MPI_DOUBLE, MPI_SUM, win);
    MPI_Win_fence(0, win); 
	
	t+=MPI_Wtime();

    if (rank == 0) {
       pi = h * (*result);
       printf("The obtained Pi value is: %.16f, the error is: %.16f time %f\n", pi, fabs(pi - PI25DT), t);
    }
	
	MPI_Win_free(&win);;

    MPI_Finalize();
}
