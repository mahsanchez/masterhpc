// Compile with mpicc -o stencil stencil.c -lm
// Example for run: mpirun -np 1 ./stencil 200 1 500
// Output: heat.svg

#include "mpi.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// row-major order
#define ind(i,j) (j)*(n+2)+i

int main(int argc, char **argv) {

  MPI_Init(&argc, &argv); 
  int rank, procnum;
  int n, energy, niters;
  
  MPI_Comm comm = MPI_COMM_WORLD;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &procnum);
  
  if(argc < 4) {
	  if (rank == 0) printf("usage: stencil_mpi <n> <energy> <niters>\n");
	  MPI_Finalize();
	  exit(1);
  }
  
  if (rank == 0) {
      n = atoi(argv[1]);
      energy = atoi(argv[2]); 
      niters = atoi(argv[3]); 
  }	  
  
  // stencil parameters
  if (rank == 0) {
      int args[3] = {n, energy, niters};
      MPI_Bcast(args, 3, MPI_INT, 0, MPI_COMM_WORLD);
  }
  else {
      int args[3];
      MPI_Bcast(args, 3, MPI_INT, 0, MPI_COMM_WORLD);
      n=args[0]; energy=args[1]; niters=args[2];
  }
  
  // Cartesian Topology Creation
  int dimension[2] = {0,0};
  MPI_Dims_create(procnum, 2, dimension);
  
  int periods[2] = {0,0};
  MPI_Comm cartesian_topology;
  MPI_Cart_create(MPI_COMM_WORLD, 2, dimension, periods, 0, &cartesian_topology);

  // Get x,y coordinates per process
  int coordinates[2];
  MPI_Cart_coords(cartesian_topology, rank, 2, coordinates);

  // Find neighbors ranks
  int source, north, south, east, west;
  MPI_Cart_shift(cartesian_topology, 0, 1, &west, &east);
  MPI_Cart_shift(cartesian_topology, 1, 1, &north, &south);
  
  int px = dimension[0];
  int py = dimension[1];
  int rx = coordinates[0];
  int ry = coordinates[1];
  
  printf("parameters rank:%d dimension{%d, %d} coordinates{%d, %d} north:%d south:%d east:%d west:%d \n", rank, px, py, rx, ry, north, south, east, west);
  
  // Split the grid on equally small tiles sizes
  int tile_width = n/px; 
  int tile_height = n/py; 
  int offset_x = rx * tile_width; 
  int offset_y = ry * tile_height; 

  int size = (tile_width+2)*(tile_height+2); // local grid size
  double *bufmem;
  MPI_Win win;
  MPI_Win_allocate(2*size*sizeof(double), sizeof(double), MPI_INFO_NULL, MPI_COMM_WORLD, &bufmem, &win);

  double *tmp;
  double *anew = bufmem; 
  double *aold = bufmem + size; 

  #define nsources 3
  int sources[nsources][2] = {{n/2,n/2}, {n/3,n/3}, {n*4/5,n*8/9}};
  
  // find out if there are energy source assigned to this process tile
  int tile[nsources][2]; 
  int lnsources = 0;
  
  for (int i=0; i < nsources; ++i) {
    int local_x = sources[i][0] - offset_x;
    int local_y = sources[i][1] - offset_y;
    if( (local_x >= 0 && local_x < tile_width) && (local_y >= 0 && local_y < tile_height)) {
      tile[lnsources][0] = local_x + 1; 
      tile[lnsources][1] = local_y + 1; 
      lnsources++;
    }
  }

  double t=-MPI_Wtime(); 
  //data type definition
  MPI_Datatype horizontal_halo_type;
  MPI_Type_contiguous(tile_width, MPI_DOUBLE, &horizontal_halo_type);
  MPI_Type_commit(&horizontal_halo_type);
  
  MPI_Datatype verticall_halo_type;
  MPI_Type_vector(tile_height, 1, tile_width + 2,MPI_DOUBLE, &verticall_halo_type);
  MPI_Type_commit(&verticall_halo_type);

  double heat; 
  for(int iter=0; iter<niters; ++iter) {
    // neighbors halo exchange   
    MPI_Win_fence(0, win);
    MPI_Put(&aold[ind(1,1)], 1, horizontal_halo_type, north, ind(1,tile_height+1), 1, horizontal_halo_type, win);
    MPI_Put(&aold[ind(1,tile_height)], 1, horizontal_halo_type, south, ind(1,0), 1, horizontal_halo_type, win);
    MPI_Put(&aold[ind(tile_width,1)], 1, verticall_halo_type, east, ind(tile_width+1,1), 1, verticall_halo_type, win);
    MPI_Put(&aold[ind(1,1)], 1, verticall_halo_type, west, ind(0,1), 1, verticall_halo_type, win);
    MPI_Win_fence(0, win);

    // calculate heat
    heat = 0.0;
    for(int j=1; j<tile_height+1; ++j) {
      for(int i=1; i<tile_width+1; ++i) {
        anew[ind(i,j)] = aold[ind(i,j)]/2.0 + (aold[ind(i-1,j)] + aold[ind(i+1,j)] + aold[ind(i,j-1)] + aold[ind(i,j+1)])/4.0/2.0;
        heat += anew[ind(i,j)];
      }
    }
	
	// update the energy
	for(int i=0; i < lnsources; ++i) {
      anew[ind(tile[i][0],tile[i][1])] += energy; 
    }

    tmp=anew; anew=aold; aold=tmp;
  }
  t+=MPI_Wtime();

  MPI_Type_free(&verticall_halo_type);
  MPI_Type_free(&horizontal_halo_type);

  // get final heat in the system
  MPI_Win_fence(0, win); 
  //printf("heat: %f rank: %d\n", heat, rank);
  MPI_Accumulate(&heat, 1, MPI_DOUBLE, 0, 0, 1, MPI_DOUBLE, MPI_SUM, win);
  MPI_Win_fence(0, win); 
  
  if(rank == 0) {
	  printf("heat: %f time: %f\n", bufmem[0], t);
  }
  
  MPI_Win_free(&win);;
  
  MPI_Finalize();
}
